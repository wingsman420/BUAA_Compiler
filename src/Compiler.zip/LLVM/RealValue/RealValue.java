package LLVM.RealValue;

public abstract class RealValue {

    public RealValue()
    {

    }
    public abstract String toString();
}
