package LLVM.classes.BlockItems;

public enum BinaryOperator {
    ADD, SUB, MUL, DIV, REM
}
