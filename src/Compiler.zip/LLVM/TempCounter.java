package LLVM;

public class TempCounter {
    public static int counter;

    public TempCounter() {
        counter = 0;
    }
}
